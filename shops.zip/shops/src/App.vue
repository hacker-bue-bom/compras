<template>

<div>  
  <nav >
    <div id="navy">
      <div class="testy">
        <router-link to="/" class="spacing">Home</router-link>
        <router-link to="/about" class="spacing">Registo</router-link>
        <router-link to="/api_search" class="spacing" v-if="(loggy==1 || addy==1)">API</router-link>
        <router-link to="/adminView" class="spacing" v-if="addy==1">Admin</router-link>
        <router-link to="/carrinho"  class="spacing" ><img src="./assets/cart.png" class="carty"/></router-link>
      </div>
      <div >
        <button class="loggy" @click="logout()" >LOGOUT</button>
      </div>
    </div>
  </nav>
  <router-view/>
  </div>
</template>

<script>
export default {
  data() {
    return {
      addy: null,
      loggy: null,
    }},
  mounted(){ 
    this.addy = localStorage.getItem('admin')
    this.loggy = localStorage.getItem('logged')
  },
  methods: {
    logout() {
      localStorage.removeItem('admin');
      localStorage.removeItem('logged');     // TEMOS DE TER ISTO ESPECIFICO PARA CADA USER?     v-if="test==1"
      this.$router.push("/");
    }
  }
}



</script>


<style>
.loggy{
  width: auto;
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
nav {
  padding: 30px;
}
nav a {
  font-weight: bold;
  color: #2c3e50;
}
nav a.router-link-exact-active {
  color: #42b983;
}
#navy{
  display: flex;
  justify-content: space-between;
}
.testy{
  padding: 20px 0;
}
.carty{
  height: 49px;
  padding: 0;
}
.spacing{
  margin-right: 20px;
}
</style>